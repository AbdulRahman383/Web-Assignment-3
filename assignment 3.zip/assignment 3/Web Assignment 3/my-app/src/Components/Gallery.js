import React from 'react'

export default function Gallery() {
    return (
    <><center><h1>Men's Suits</h1></center><div class="main">
            <div>
                <h1>BLACK</h1>
                <img src="black.jpg" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
            <div>
                <h1>GREEN</h1>
                <img src="green.webp" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
            <div>
                <h1>WHITE</h1>
                <img src="white.jpg" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
            <div>
                <h1>GRAY</h1>
                <img src="grey.jpg" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
            <div>
                <h1>NAVY</h1>
                <img src="navy blue.jpg" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
            <div>
                <h1>ROYAL</h1>
                <img src="royal blue.jpg" width="200" height="130"></img>
                <button id="button" type="submit">BUY</button>
            </div>
        </div><center><h1>Women's Clothing</h1></center><div class="main">
                <div>
                    <h1>Saree</h1>
                    <img src="saree.jpg.crdownload" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Lawn Suit</h1>
                    <img src="lawn.jpeg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Velvet Fabric</h1>
                    <img src="febric.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Round Neck</h1>
                    <img src="round.webp" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Georgette</h1>
                    <img src="Georgette.webp" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Chiffon</h1>
                    <img src="chiffon.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
            </div><center><h1>Kid's Clothing</h1></center><div class="main">
                <div>
                    <h1>Hoodie</h1>
                    <img src="hoodie.webp.crdownload" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>T-Shirt</h1>
                    <img src="tshirt.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Casual Shirt</h1>
                    <img src="casual.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Kurta</h1>
                    <img src="kurta.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Cartoon T-Shirt</h1>
                    <img src="cartoon.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
                <div>
                    <h1>Sleeveless T-Shirt</h1>
                    <img src="Sleeveless.jpg" width="200" height="130"></img>
                    <button id="button" type="submit">BUY</button>
                </div>
            </div></>
    )
}
